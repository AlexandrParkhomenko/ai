from builtins import range
from builtins import object
import numpy as np
from past.builtins import xrange


class KNearestNeighbor(object):
    """ Классификатор kNN """

    def __init__(self):
        pass

    def train(self, X, y):
        """
        Обучение классификатора. 

        Inputs:
        - X: Массив обучающих данных размером (num_train, D), содержащий
             num_train образцов размерности D.
        - y: Массив numpy размером (N,) содержащий обучающие метки, где
          y[i] - метка для X[i].
        """
        self.X_train = X
        self.y_train = y

    def predict(self, X, k=1, num_loops=0):
        """
        Прогнозирование меток для тестовых даннх.

        Inputs:
        - X: Массив тестовых данных размером (num_train, D) содержащий
             num_train образцов размерности D.
        - k: Число ближайших соседей, которые будут голосовать за метки.
        - num_loops: Определяет, какую реализацию использовать для вычисления расстояний между
                     обучающими и тестовыми точками.

        Returns:
        - y: Массив numpy размером (num_test,) содержащий прогнозы меток для тестовых данных,
             где y[i] это прогноз метки для точки X[i].
        """
        if num_loops == 0:
            dists = self.compute_distances_no_loops(X)
        elif num_loops == 1:
            dists = self.compute_distances_one_loop(X)
        elif num_loops == 2:
            dists = self.compute_distances_two_loops(X)
        else:
            raise ValueError('Неверное значение %d для num_loops' % num_loops)

        return self.predict_labels(dists, k=k)

    def compute_distances_two_loops(self, X):
        """
        Вычисление расстояния между каждой тестовой точкой в X и каждой обучающей точкой
        в self.X_train с помощью вложенного цикла.

        Inputs:
        - X: Массив тестовых данных.

        Returns:
        - dists: Массив numpy размером (num_test, num_train) где dists[i, j] -
                 это евклидово расстояние между i-й тестовой точкой и j-1 обучающей точкой.
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        for i in range(num_test):
            for j in range(num_train):
                #####################################################################
                # TODO:                                                             #
                # Вычислите расстояние L2 между i-й тестовой точкой и j-й обучающей #
                # точкой, а затем сохраните результат в dists[i, j]. Постарайтесь   #
                # не использовать дополнительные циклы и функцию np.linalg.norm().  #
                #####################################################################
                # *****START OF YOUR CODE*****

                pass

                # *****END OF YOUR CODE*****
        return dists

    def compute_distances_one_loop(self, X):
        """
        Вычисление расстояния между каждой тестовой точкой в X и каждой обучающей точкой
        в self.X_train с помощью одного цикла.

        Input / Output: аналогичные предыдущей функции
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        for i in range(num_test):
            #######################################################################
            # TODO:                                                               #
            # Вычислите расстояние L2 между i-й тестовой точкой и всеми           #
            # обучающими точками, а затем сохраните результат в dists[i, :].      #
            # Не используйте np.linalg.norm().                                    #
            #######################################################################
            # *****START OF YOUR CODE*****

            pass

            # *****END OF YOUR CODE*****
        return dists

    def compute_distances_no_loops(self, X):
        """
        Вычисление расстояния между каждой тестовой точкой в X и каждой обучающей точкой
        в self.X_train без использзования циклов.

        Input / Output: аналогичные
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        #########################################################################
        # TODO:                                                                 #
        # Вычислите расстояние L2 между всеми тестовыми и обучающими точками    #
        # без использования циклов; результат сохраните в dists.                #
        #                                                                       #
        # Реализуйте эту функцию, используя только базовые операции с массивами #
        # без функций scipy и np.linalg.norm().                                 #
        #                                                                       #
        # Подсказка: Попробуйте использовать умножение матриц                   #
        #########################################################################
        # *****START OF YOUR CODE*****

        pass

        # *****END OF YOUR CODE*****
        return dists

    def predict_labels(self, dists, k=1):
        """
        Предсказание меток с помощью матрицы расстояний между тестовыми и обучающими точками.

        Inputs:
        - dists: Массив numpy array размером (num_test, num_train) где dists[i, j] -
                 это расстояние между i-й тестовой точкой и j-й обучающей точкой.

        Returns:
        - y: Массив numpy размером (num_test,) содержащий прогноз меток для тестовых данных,
             где y[i] это прогноз метки для точки X[i].
        """
        num_test = dists.shape[0]
        y_pred = np.zeros(num_test)
        for i in range(num_test):
            # Список длиной k содержит метки k ближайших соседей
            closest_y = []
            #########################################################################
            # TODO:                                                                 #
            # Используйте матрицу расстояний, чтобы найти k ближайших соседей для   #
            # i-й тестовой точки, затем используйте self.y_train и найдите метки    #
            # этих соседей. Сохраните метки в closest_y.                           #
            # Подсказка: Посмотрите на функцию numpy.argsort.                       #
            #########################################################################
            # *****START OF YOUR CODE*****

            pass

            # *****END OF YOUR CODE*****
            #########################################################################
            # TODO:                                                                 #
            # Теперь вам необходимо найти наиболее подходящую (часто встречающуюся) #
            # метку в списке closest_y.                                             #
            # Сохраните её в y_pred[i].                                             #
            #########################################################################
            # *****START OF YOUR CODE*****

            pass

            # *****END OF YOUR CODE*****

        return y_pred
