# python-labs
Labs for CS41

## TODO:

* [Parth] Add Lab 1 MD with links for setting up Python.
* Combine Functions and FP in Lab 4
* [Michael] Add `Pandas` into `numpy` for Lab 6
* Write Lab 8 with SL & 3P & Plt
