#!/usr/bin/env python3
"""Reference solutions to Lab 7 for CS41: Hap.py Code.

There isn't any programming specific to Lab 7!
These solutions are intentionally blank.

Revision history:
@sredmond 2016-05-10 Created
"""
