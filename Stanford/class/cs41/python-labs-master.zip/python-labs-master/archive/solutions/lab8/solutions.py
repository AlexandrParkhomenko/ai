#!/usr/bin/env python3
"""Reference solutions to Lab 8 for CS41: Hap.py Code.

There isn't any programming specific to Lab 8!
These solutions are intentionally blank.

Revision history:
@sredmond 2016-05-17 Created
"""
