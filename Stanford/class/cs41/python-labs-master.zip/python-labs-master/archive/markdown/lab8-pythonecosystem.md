# Lab 8: The Python Ecosystem

## Overview

Today is dedicated for you to work on your final projects, so this lab is just a placeholder.

If you haven't yet voted, please vote [on Piazza (@119)](https://piazza.com/class/ikyirahpqdy5sg?cid=119) for the topics you'd like to learn more about next lecture.

Besides that, you're free to work on your final project. Wave down a course staff member if you're stuck at any part of the process! We're here to help.

> With <3 by @sredmond