# Задание для курса "Свёрточные нейроныне сети для визуального распознавания".

## Настройка
Для запуска проектов можно использовать виртуальную среду.

**1. Anaconda:**

Для настройки среды выполните команду:

`conda create -n cs231n python=3.7 anaconda`

Затем активируйте среду и подключитесь к ней:

`source activate cs231n`

Чтобы выйти, просто закройте окно или введите:

`source deactivate cs231n`

**2. Python virtualenv:**

Второй вариант - использовать среду virtualenv. Для настройки используйте следующие команды:

`cd assignment2`
`sudo pip install virtualenv`    
`virtualenv -p python3 .env`       
`source .env/bin/activate`         
`pip install -r requirements.txt`

Чтобы закрыть среду, введите `deactivate`.

## Запуск Jupyter Notebook
Вы можете использовать Jupyter Notebook и Jupyter Lab для запуска .ipynb-файлов.

https://jupyterlab.readthedocs.io/en/stable/getting_started/installation.html

## Выполнение заданий
**1: Полосвязная нейронная сеть**

В блокноте **FullyConnectedNets.ipynb** вы найдёте все необходимые инструкции для реализации полносвязной нейросети.

**2: Пакетная нормализация (Batch Normalization)**

Задание находится в файле **BatchNormalization.ipynb**.

**3: Dropout**

Задание находится в файле **Dropout.ipynb**.

**4: Свёрточные нейросети (CNN)**

Задание находится в файле **ConvolutionalNetworks.ipynb**.